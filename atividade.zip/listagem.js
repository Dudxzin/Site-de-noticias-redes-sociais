let dados=[];
function carregar(){
  $.get('https://jsonplaceholder.typicode.com/posts', r=>{
    dados = r;
    $('#filtro').select2({
      data: r.map(p=>({id:p.id, text:p.title}))
    });
    preencherTabela(r);
  });
}
function preencherTabela(arr){
  const tbody = $('#tabela tbody');
  tbody.empty();
  arr.forEach(p=>{
    tbody.append(`<tr>
     <td>${p.id}</td><td>${p.userId}</td><td>${p.title}</td><td>${p.body}</td>
     <td><button onclick="voltarCadastro()">Cadastrar Novo</button></td>
    </tr>`);
  });
  $('#tabela').DataTable();
}
function voltarCadastro(){ window.location='cadastro.html'; }

$('#filtro').on('change', function(){
  const id = Number($(this).val());
  const filtrado = dados.filter(p=>p.id===id);
  $('#tabela').DataTable().destroy();
  preencherTabela(filtrado);
});

carregar();
