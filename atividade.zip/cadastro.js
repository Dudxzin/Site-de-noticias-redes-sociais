$('#formLivro').on('submit', function(e){
  e.preventDefault();
  const data = {
    userId: $('#userId').val(),
    id: $('#id').val(),
    title: $('#title').val(),
    body: $('#body').val()
  };
  $.ajax({
    url:'https://jsonplaceholder.typicode.com/posts',
    method:'POST',
    contentType:'application/json',
    data: JSON.stringify(data),
    success: ()=> alert('Enviado com sucesso!')
  });
});
